<?php
/* Smarty version 3.1.32, created on 2018-08-22 17:26:44
  from 'C:\xampp\htdocs\smarty\templates\rodape.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7d80b4dcefb4_76883369',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '86d196c86b0c11b66dab9188012fb480177fd877' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\rodape.tpl',
      1 => 1534951575,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7d80b4dcefb4_76883369 (Smarty_Internal_Template $_smarty_tpl) {
?></div>



</body>
</html><?php }
}
