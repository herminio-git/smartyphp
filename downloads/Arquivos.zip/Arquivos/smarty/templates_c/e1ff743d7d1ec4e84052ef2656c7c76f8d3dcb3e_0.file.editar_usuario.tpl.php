<?php
/* Smarty version 3.1.32, created on 2018-08-22 21:52:29
  from 'C:\xampp\htdocs\smarty\templates\editar_usuario.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7dbefdba86e8_46940858',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e1ff743d7d1ec4e84052ef2656c7c76f8d3dcb3e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\editar_usuario.tpl',
      1 => 1534967516,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7dbefdba86e8_46940858 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="col-md-9">
	
	<div class="panel panel-primary">
		<div class="panel panel-heading">
			<center><b>Editar Usuários</b></center>
		</div>
		<div class="panel-body" width="95%">
			<table id="tb_usuario" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<th>ID</th>
					<th>Nome</th>
					<th>Usuário</th>
					<th>Opções</th>
				</thead>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['array_usuarios']->value, 'tb_usuario');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tb_usuario']->value) {
?>
				<tr>
					<td><?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['id_usuario'];?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['nome_completo'];?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['usuario'];?>
</td>
					<td>
						<a href="index.php?ac=editar&id=<?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['id_usuario'];?>
" class="btn btn-primary"><i class="fas fa-user-edit  mr-2"></i>Editar</a>

						<a href="index.php?ac=excluir&id=<?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['id_usuario'];?>
" class="btn btn-danger"><i class="far fa-trash-alt mr-2"></i>Excluir</a>
					</td>
				</tr>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			</table>
		</div>
	</div>

</div>

<!--
<?php echo '<script'; ?>
 type="text/javascript">
	$(document).ready(function(){
		$("#tb_usuario").DataTable();
	});
<?php echo '</script'; ?>
><?php }
}
