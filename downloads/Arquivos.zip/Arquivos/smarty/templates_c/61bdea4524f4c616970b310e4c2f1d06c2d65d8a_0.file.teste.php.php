<?php
/* Smarty version 3.1.32, created on 2018-08-21 16:34:56
  from 'C:\xampp\htdocs\smarty\templates\teste.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7c2310303521_97864783',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '61bdea4524f4c616970b310e4c2f1d06c2d65d8a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\teste.php',
      1 => 1534862089,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7c2310303521_97864783 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	
	<title>Bem vindos</title>
</head>
<body>
	<h3><?php echo $_smarty_tpl->tpl_vars['var1']->value;?>
</h3>
	<h4><?php echo $_smarty_tpl->tpl_vars['var2']->value;?>
</h4>
	<h5><?php echo $_smarty_tpl->tpl_vars['var3']->value;?>
</h5>
	<hr>
	<h2>Array</h2>
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['array']->value, 'dados');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dados']->value) {
?>
	<b>Nome:</b><?php echo $_smarty_tpl->tpl_vars['dados']->value['nome'];?>
<br>
	<b>SobreNome:</b><?php echo $_smarty_tpl->tpl_vars['dados']->value['sobrenome'];?>
<br><br>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	<a href="" class="btn btn-success">Botao</a>
</body>
</html><?php }
}
