<?php
/* Smarty version 3.1.32, created on 2018-08-22 20:33:35
  from 'C:\xampp\htdocs\smarty\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7dac7f7f8d45_98610118',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c043ce1d0c6dbbf74066149c0ad39819e1f61b50' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\login.tpl',
      1 => 1534952767,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7dac7f7f8d45_98610118 (Smarty_Internal_Template $_smarty_tpl) {
?>	<div class="default col-md-9">
		<div class="panel panel-primary">
			<div class="panel panel-heading">
				<center><b>Efetuar Login</b></center>
			</div>
			<div class="panel-body" width="95%">
				<form name="registrar_usuario" method="post">
					<?php echo $_smarty_tpl->tpl_vars['alerta']->value;?>

					

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Usuário&nbsp   
							</span>
							<input type="text" name="usuario" id="usuario" class="form-control" placeholder="Insira seu nome de usuário"  required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Senha&nbsp &nbsp 
							</span>
							<input type="password" name="senha" id="senha" class="form-control" placeholder="Insira sua senha" required>
						</div>
					</div>


					

					<center>
						<input type="submit" name="btn_inserir" value="Login" class="btn btn-primary">
						
					</center>

				</form>
			</div>
		</div>
	</div>
</div><?php }
}
