<?php
/* Smarty version 3.1.32, created on 2018-08-22 23:04:38
  from 'C:\xampp\htdocs\smarty\templates\rel_usuario.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7dcfe6642253_03925381',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3ee84041eced8800d26c87f9e61707a484a0c7e3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\rel_usuario.tpl',
      1 => 1534971875,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7dcfe6642253_03925381 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="col-md-9">
	
	<div class="panel panel-primary mb=2">
		<div class="panel panel-heading">
			<center><b>Relatório de Usuários - <?php echo $_smarty_tpl->tpl_vars['data_atual']->value;?>
</b></center>
		</div>
		<div class="panel-body" width="95%">
			<table id="tb_usuario" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<th>ID</th>
					<th>Nome</th>
					<th>Usuário</th>
					
				</thead>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['array_usuarios']->value, 'tb_usuario');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tb_usuario']->value) {
?>
				<tr>
					<td><?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['id_usuario'];?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['nome_completo'];?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['tb_usuario']->value['usuario'];?>
</td>
					
				</tr>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			</table>

			
		</div>
		<div class="mb-4">
			<center>
				<a href="index.php" class="btn btn-danger para_imprimir">Cancelar</a>
				<button class="btn btn-success para_imprimir" onclick="imprimir_rel()">Imprimir</button>
			</center>
		</div>
	</div>

</div>




<?php echo '<script'; ?>
 type="text/javascript">
	function imprimir_rel(){
		$(".para_imprimir").hide();
		window.print();
		$(".para_imprimir").show();
	}
<?php echo '</script'; ?>
>

<!--
<?php echo '<script'; ?>
 type="text/javascript">
	$(document).ready(function(){
		$("#tb_usuario").DataTable();
	});
<?php echo '</script'; ?>
><?php }
}
