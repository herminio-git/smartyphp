<?php
/* Smarty version 3.1.32, created on 2018-08-23 01:00:25
  from 'C:\xampp\htdocs\smarty\templates\editar_func.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7deb090992b3_46933599',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4ee8e09783cb596e52608685e549dc4e722424f7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\editar_func.tpl',
      1 => 1534978487,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7deb090992b3_46933599 (Smarty_Internal_Template $_smarty_tpl) {
?>	<div class="default col-md-9">
		<div class="panel panel-primary">
			<div class="panel panel-heading">
				<center><b>Editar Funcionário</b></center>
			</div>
			<div class="panel-body" width="95%">
				<form name="registrar_usuario" method="post">
					
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Nome Completo &nbsp 
							</span>
							<input type="text" name="nome_completo" id="nome_completo" class="form-control" placeholder="Insira seu nome completo" value="<?php echo $_smarty_tpl->tpl_vars['nome_completo']->value;?>
" required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								CPF&nbsp &nbsp &nbsp   
							</span>
							<input type="text" name="cpf" id="cpf" class="form-control" placeholder="Insira seu CPF" value="<?php echo $_smarty_tpl->tpl_vars['cpf']->value;?>
"  required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Endereço&nbsp &nbsp &nbsp &nbsp
							</span>
							<input type="text" name="endereco" id="endereco" class="form-control" placeholder="Insira seu endereço" value="<?php echo $_smarty_tpl->tpl_vars['endereco']->value;?>
" required>
						</div>
					</div>


					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Telefone
							</span>
							<input type="text" name="telefone" id="telefone" class="form-control" placeholder="Insira seu telefone" value="<?php echo $_smarty_tpl->tpl_vars['telefone']->value;?>
" required>
						</div>
					</div>

					<input type="hidden" name="id_funcionario" id="id_funcionario" value="<?php echo $_smarty_tpl->tpl_vars['id_funcionario']->value;?>
">

					<center>
						<input type="submit" name="btn_editar" value="Editar Funcionário" class="btn btn-primary">
						<a href="index.php" class="btn btn-danger">&nbsp &nbsp &nbspCancelar&nbsp &nbsp &nbsp </a>
					</center>

				</form>
			</div>
		</div>
	</div>
</div><?php }
}
