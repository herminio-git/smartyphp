<?php
/* Smarty version 3.1.32, created on 2018-08-23 00:49:02
  from 'C:\xampp\htdocs\smarty\templates\menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7de85ea94df6_04991494',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4aa40ed9d60f48e67ff3da192b8a1e27cecf0367' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\menu.tpl',
      1 => 1534978138,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7de85ea94df6_04991494 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row">
	<div class="default col-md-3 para_imprimir">
		<div class="list-group">
			<a href="#" class="list-group-item active">Menu Usuários</a>
			
			<a href="index.php?ac=registrar_usuario" class="list-group-item <?php echo $_smarty_tpl->tpl_vars['botao']->value;?>
">Inserir Usuário</a>
			<a href="index.php?ac=editar_usuario" class="list-group-item <?php echo $_smarty_tpl->tpl_vars['botao']->value;?>
">Editar Usuário</a>
			<a href="index.php?ac=rel_usuario" class="list-group-item">Relatório Usuário</a>
			<a href="sair.php" class="list-group-item ">Sair</a>
		</div>

		<div class="list-group mt-3">
			<a href="#" class="list-group-item active">Menu Funcionários</a>
			
			<a href="index.php?ac=registrar_funcionario" class="list-group-item">Inserir Funcionário</a>
			<a href="index.php?ac=editar_funcionario" class="list-group-item">Editar Funcionário</a>
			<a href="#" class="list-group-item">Relatório Funcionário</a>
		</div>

	</div><?php }
}
