<?php
/* Smarty version 3.1.32, created on 2018-08-22 20:31:23
  from 'C:\xampp\htdocs\smarty\templates\editar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7dabfbc72db6_38331198',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'da60c784405f28cd5bc67a662e62430636264b99' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\editar.tpl',
      1 => 1534962293,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7dabfbc72db6_38331198 (Smarty_Internal_Template $_smarty_tpl) {
?>	<div class="default col-md-9">
		<div class="panel panel-primary">
			<div class="panel panel-heading">
				<center><b>Editar Usuário</b></center>
			</div>
			<div class="panel-body" width="95%">
				<form name="registrar_usuario" method="post">
					
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Nome Completo &nbsp 
							</span>
							<input type="text" name="nome_completo" id="nome_completo" class="form-control" placeholder="Insira seu nome completo" value="<?php echo $_smarty_tpl->tpl_vars['nome_completo']->value;?>
" required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Nome Usuário&nbsp &nbsp &nbsp   
							</span>
							<input type="text" name="usuario" id="usuario" class="form-control" placeholder="Insira seu nome de usuário" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value;?>
"  required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Senha&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
							</span>
							<input type="password" name="senha" id="senha" class="form-control" placeholder="Insira sua senha" value="<?php echo $_smarty_tpl->tpl_vars['senha']->value;?>
" required>
						</div>
					</div>


					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Confirmar Senha
							</span>
							<input type="password" name="confirmar_senha" id="confirmar_senha" class="form-control" placeholder="Confirme sua senha" value="<?php echo $_smarty_tpl->tpl_vars['confirmar_senha']->value;?>
" required>
						</div>
					</div>

					<input type="hidden" name="id_usuario" id="id_usuario" value="<?php echo $_smarty_tpl->tpl_vars['id_usuario']->value;?>
">

					<center>
						<input type="submit" name="btn_editar" value="Editar Usuário" class="btn btn-primary">
						<a href="index.php" class="btn btn-danger">&nbsp &nbsp &nbspCancelar&nbsp &nbsp &nbsp </a>
					</center>

				</form>
			</div>
		</div>
	</div>
</div><?php }
}
