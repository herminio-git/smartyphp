<?php
/* Smarty version 3.1.32, created on 2018-08-23 00:40:47
  from 'C:\xampp\htdocs\smarty\templates\registrar_funcionario.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b7de66ff1f0f5_63447505',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3262ec8fc4c7961083a6fb84e70878217107c326' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\templates\\registrar_funcionario.tpl',
      1 => 1534977618,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b7de66ff1f0f5_63447505 (Smarty_Internal_Template $_smarty_tpl) {
?>	<div class="default col-md-9">
		<div class="panel panel-primary">
			<div class="panel panel-heading">
				<center><b>Adicionar Funcionário</b></center>
			</div>
			<div class="panel-body" width="95%">
				<form name="registrar_usuario" method="post">
					<?php echo $_smarty_tpl->tpl_vars['alerta']->value;?>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Nome Completo &nbsp 
							</span>
							<input type="text" name="nome_completo" id="nome_completo" class="form-control" placeholder="Insira seu nome completo" required>
						</div>
					</div>


					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								CPF&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
							</span>
							<input type="text" name="cpf" id="cpf" class="form-control" placeholder="Insira seu CPF" required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Endereço&nbsp &nbsp &nbsp   
							</span>
							<input type="text" name="endereco" id="endereco" class="form-control" placeholder="Insira seu endereço"   required>
						</div>
					</div>

					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								Telefone&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
							</span>
							<input type="text" name="telefone" id="telefone" class="form-control" placeholder="Insira seu telefone" required>
						</div>
					</div>


					

					<center>
						<input type="submit" name="btn_inserir" value="Inserir Funcionário" class="btn btn-primary">
						<a href="index.php" class="btn btn-danger">&nbsp &nbsp &nbspCancelar&nbsp &nbsp &nbsp </a>
					</center>

				</form>
			</div>
		</div>
	</div>
</div><?php }
}
