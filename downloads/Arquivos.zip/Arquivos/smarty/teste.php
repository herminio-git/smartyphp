<?php 

include("includes/config.ini.php");


$minha_var = "Bem vindo ao nosso curso de Smarty com PHP!!";

$smarty->assign("minha_var", $minha_var);

$array = array();
$array[0]["nome"]="Hugo";
$array[0]["sobrenome"]="Paula";
$array[1]["nome"]="Marcos";
$array[1]["sobrenome"]="Paulo";
$array[2]["nome"]="Pedro";
$array[2]["sobrenome"]="Santos";

$smarty->assign("array", $array);

$smarty->assign(array(
	'var1'=>'Bem vindos!!', 
	'var2'=>'Curso de Smarty!!', 
	'var3'=>'Professor Hugo Freitas!!'
));

$smarty->display("teste.php");

 ?>