<!DOCTYPE html>
<html>
<head>
	
	<title>Bem vindos</title>
</head>
<body>
	<h3>{$var1}</h3>
	<h4>{$var2}</h4>
	<h5>{$var3}</h5>
	<hr>
	<h2>Array</h2>
	{foreach from=$array item=dados}
	<b>Nome:</b>{$dados.nome}<br>
	<b>SobreNome:</b>{$dados.sobrenome}<br><br>
	{/foreach}
	<a href="" class="btn btn-success">Botao</a>
</body>
</html>